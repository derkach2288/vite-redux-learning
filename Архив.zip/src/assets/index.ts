export { default as WeatherImage } from "./weather.png";
export { default as Temp } from "./temp.png";
