export { default as WeatherImage } from "./weather.png";
export { default as Temp } from "./temp.png";
export { default as Like} from "./like.png"
export { default as DisLike} from "./dislike.png"
export { default as Logo} from "./logo.jpg"
export { default as NotesImg} from "./notes.jpeg"
