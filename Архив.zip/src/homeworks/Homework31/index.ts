import Homework31 from "./Homework31";

export default Homework31;