import Feedback from "components/Feedback"
import { Homework31Wrapper } from "./styles"

function Homework31() {
  return (
    <Homework31Wrapper>
      <Feedback />
    </Homework31Wrapper>
  )
}

export default Homework31
