import {styled} from "styled-components"

export const Homework31Wrapper = styled.div`
  display: flex;
  flex: 1;
  padding: 40px;
  justify-content: center;
`