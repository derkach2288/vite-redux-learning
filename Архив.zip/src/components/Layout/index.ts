import Layout from "./Layout";

export default Layout;
