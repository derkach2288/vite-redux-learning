import InputWeather from "./InputWeather";

export default InputWeather;