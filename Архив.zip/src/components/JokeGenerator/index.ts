import JokeGenerator from "./JokeGenerator";

export default JokeGenerator;