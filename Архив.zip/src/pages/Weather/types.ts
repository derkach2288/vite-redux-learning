import { ReactNode } from "react";

export interface WeatherPrpps {
  children: ReactNode
}