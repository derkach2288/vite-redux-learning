import ErrorInfo from "./ErrorInfo";

export default ErrorInfo;