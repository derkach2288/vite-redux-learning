import WeatherInfo from "./WeatherInfo";

export default WeatherInfo;