import Counter from "components/Counter"
import { Lesson30Wrapper } from "./styles"

function Lesson30() {
  return (
    <Lesson30Wrapper>
      <Counter />
    </Lesson30Wrapper>
  )
}

export default Lesson30
