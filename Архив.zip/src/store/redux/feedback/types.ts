export interface FeedbackInitialState {
  countLike: number
  countDisLike: number
}
