import GlobalStyles from "styles/GlobalStyles"
// import Homework29 from "homeworks/Homework29"
import Lesson30 from "lessons/Lesson30"

function App() {
  return (
    <>
      <GlobalStyles />
      {/* <Homework29 /> */}
      <Lesson30 />
    </>
  )
}

export default App
